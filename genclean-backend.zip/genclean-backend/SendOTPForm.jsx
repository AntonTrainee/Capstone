import { useState } from "react";
import axios from "axios";

function SendOTPForm({ onSent }) {
  const [email, setEmail] = useState("");
  const [status, setStatus] = useState("");

  const handleSendOTP = async () => {
    try {
      const response = await axios.post("http://localhost:3007/send-otp", {
        email,
      });

      if (response.data.success) {
        setStatus("OTP sent to your email.");
        onSent(email); 
      } else {
        setStatus("Failed to send OTP.");
      }
    } catch (error) {
      console.error("Error:", error);
      setStatus("Error sending OTP.");
    }
  };

  return (
    <div>
      <h2>Send OTP</h2>
      <input
        type="email"
        placeholder="Enter your email"
        value={email}
        onChange={(e) => setEmail(e.target.value)}
      />
      <button onClick={handleSendOTP}>Send OTP</button>
      <p>{status}</p>
    </div>
  );
}

export default SendOTPForm;