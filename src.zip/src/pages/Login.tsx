function Login() {
  return (
    <>
      <div className="colorscheme">
        <div className="blue-box">
          <h1 className="logo" style={{ textAlign: "center" }}>
            Genclean
          </h1>
        </div>
        <div className="white-box d-flex flex-column align-items-center justify-content-center">
          <h1 className="createAcc mb-4">Login</h1>

          <div className="form-floating mb-3 w-75">
            <input
              type="text"
              className="form-control"
              placeholder="Email Addresss"
            />
            <label>Email Address</label>
          </div>

          <div className="form-floating mb-3 w-75">
            <input
              type="text"
              className="form-control"
              placeholder="Password"
            />
            <label>Password</label>
          </div>
          <button className="btn crAct-btn">Login</button>
        </div>
      </div>
    </>
  );
}

export default Login;
